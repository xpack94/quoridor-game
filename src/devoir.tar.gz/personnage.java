import java.awt.Color;


public class personnage {

	String position;
	String nom;
	 Color couleur;
	 int walls;
	 char fin;
	
	
	personnage(String position,String nom,Color couleur,int walls,char fin){
		this.position=position;
		this.nom=nom;
		this.couleur=couleur;
		this.walls=walls;
		this.fin=fin;
	}
	

}
